<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('canals', 'CanalController@index')->name('CanalIndex');
Route::get('create', 'CanalController@create')->name('canalsCreate');
Route::get('edit', 'CanalController@edit')->name('canalsEdit');
Route::get('update', 'CanalController@update')->name('canalsUpdate');
Route::get('store', 'CanalController@store')->name('canalsStore');


Route::get('storeP', 'ProgramaController@store')->name('programasStore');
Route::get('createP', 'ProgramaController@create')->name('programasCreate');

Route::get('storeG', 'GraellaController@store')->name('graellaStore');
Route::get('createG', 'GraellaController@create')->name('graellaCreate');
Route::get('viewG', 'GraellaController@index')->name('visualizar');
