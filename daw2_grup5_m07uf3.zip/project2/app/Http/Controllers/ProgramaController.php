<?php   
    namespace app\Http\Controllers;
    use App\Programa;

    use Illuminate\Http\Request;
    
    class ProgramaController extends Controller
    {
        public function index()
        {
            return view('programas.index');
        }
        public function create()
    {
        $Canales = \DB::table('canals')->select('id','nameCanal')->get();
        return view('programas.create', compact('Canales'));
    }
    public function store(Request $request)
    {
        $Programa = new Programa([
            'namePrograma' => $request->get('namePrograma'),
            'descripcio' => $request->get('descripcio'),
            'tipo' => $request->get('tipo'),
            'clasificacion' => $request->get('clasificacion'),
            'idCanal' => $request->get('idCanal')
           ]);
           $Programa->save();
        return redirect()->route('home');
    }
    public function show($id)
    {
        //
    }
    public function edit()
    {
    
    }
    public function update(Request $request)
    {
        $this->validate($request,[
            'id'    =>  'required',
            'nameCanal' =>  'required'
        ]);
        $canal = Canal::find($request->get('id'));
        $canal->nameCanal = $request->get('nameCanal');
        $canal->save();
        return redirect()->route('home')->with('success','Data Updated');
    }
    public function destroy($id)
    {
        //
    }
}