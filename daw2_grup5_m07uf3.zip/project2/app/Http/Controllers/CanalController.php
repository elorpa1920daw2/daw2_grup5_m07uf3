<?php   
    namespace app\Http\Controllers;
    use App\Canal;

    use Illuminate\Http\Request;
    
    class CanalController extends Controller
    {
        public function index()
        {
            return view('canals.index');
        }
        public function create()
    {
        return view('canals.create');
    }
    public function store(Request $request)
    {
        $nombreCanal = new Canal([
            'nameCanal' => $request->get('nameCanal'),
           ]);
           $nombreCanal->save();
        return redirect()->route('home');
    }
    public function show($id)
    {
        //
    }
    public function edit()
    {
        $Canales = \DB::table('canals')->select('id','nameCanal')->get();
        return view('canals.edit', compact('Canales'));
    }
    public function update(Request $request)
    {
        $this->validate($request,[
            'id'    =>  'required',
            'nameCanal' =>  'required'
        ]);
        $canal = Canal::find($request->get('id'));
        $canal->nameCanal = $request->get('nameCanal');
        $canal->save();
        return redirect()->route('home')->with('success','Data Updated');
    }
    public function destroy($id)
    {
        //
    }
}