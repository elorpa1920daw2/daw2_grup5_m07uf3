<?php   
    namespace app\Http\Controllers;
    use App\Graella;
    use App\Programa;
    use App\Canal;

    use Illuminate\Http\Request;
    
    class GraellaController extends Controller
    {
        public function index()
        {
            $programas= Programa::all();
            $graellas = Graella::all();
            $canals = Canal::all();

            return view('graella.index', compact('programas','graellas','canals'));
        }

    public function create()
    {
        $programas = \DB::table('programas')->select('id', 'namePrograma')->get();
        return view('graella.create',compact('programas'));
    }
    public function store(Request $request)
    {
        $nuevaGraella = new Graella([
            'dia' => $request->get('dia'),
            'hora' => $request->get('hora')
        ]);
        $nuevaGraella->save();
        $nuevaGraella ->programas() ->attach($request->idPrograma);
        return redirect()->route('visualizar');
    }
    public function show($id)
    {
        //
    }
    public function edit()
    {

    }
    public function update(Request $request)
    {

    }
    public function destroy($id)
    {
        //
    }
}