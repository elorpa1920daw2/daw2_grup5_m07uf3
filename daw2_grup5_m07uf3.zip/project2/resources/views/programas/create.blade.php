<html>
<body>
<a href="{{route('home')}}"><button>Volver</button></a><br><br>
<h2 style="text-align: center;">Crear un programa</h3>

<form style="margin-left: 30px;" method="GET" action="{{route('programasStore')}}">
    <label for='namePrograma'>Nombre Programa:</label>
    <input name="namePrograma" type="text"><br><br>
    <label for='descripcio'>Descripció:</label>
    <input name="descripcio" type="text"><br><br>
    <label for='tipo'>Tipo:</label>
    <select name="tipo">
        <option value="documental">Documental</option>
        <option value="deportes">Deportes</option>
        <option value="serie">Serie</option>
        <option value="pelicula">Pelicula</option>
        <option value="concurso">Concurso</option>
        <option value="informativo">Informativo</option>
    </select><br><br>
    <label for='clasificacion'>Clasificacion:</label>
    <select name="clasificacion">
        <option value="todos los publicos">Todos los publicos</option>
        <option value="+7">+7</option>
        <option value="+12">+12</option>
        <option value="+16">+16</option>
        <option value="+18">+18</option>
    </select><br><br>
    <label for='idCanal'>Canal:</label>
    <select name="idCanal">
        @foreach($Canales as $C)
            <option value="{{$C-> id}}">{{$C-> nameCanal}}</option>
        @endforeach
    </select><br><br>
    <input value="Crear Programa" type="submit">
</form>
</body>
</html>