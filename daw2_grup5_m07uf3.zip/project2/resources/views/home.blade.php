@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <a href="{{route('CanalIndex')}}">Index</a><br>
                    <a href="{{route('canalsCreate')}}">Crear Canal</a><br>
                    <a href="{{route('canalsEdit')}}">Editar Canal</a><br>
                    <a href="{{route('programasCreate')}}">Crear un programa</a><br>
                    <a href="{{route('graellaCreate')}}">Crear una graella</a><br>
                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
