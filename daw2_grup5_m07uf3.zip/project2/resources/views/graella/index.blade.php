<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
</head>
<body class="p-3 mb-2">
    <a href="{{route('home')}}" class="btn btn-dark">Volver</a><br><br>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th>Código</th>
                <th>Canal</th>
                <th>Programa</th>
                <th>Dia</th>
                <th>Hora</th>
            </tr>
        </thead>
        <tbody>
        @foreach($graellas as $graella)
        <tr>
        <td>{{$graella-> id}}</td>
        <td>@foreach($graella-> programas as $programa)
                @foreach ($canals as $canal)
                    @if($programa->idCanal == $canal->id)
                    {{$canal->nameCanal}}
                    @endif
                @endforeach
            @endforeach
        </td>
        <td>
            @foreach($graella->programas as $programa)
                {{$programa->namePrograma}}
            @endforeach
        </td>
        <td>
            {{ $graella->dia }}
        </td>
        <td>
            {{ $graella->hora }}
        </td>
            @endforeach
        </tr>
        </tbody>
    </table>
</body>
</html>
