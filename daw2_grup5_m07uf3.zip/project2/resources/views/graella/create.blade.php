<html>
<head>
</head>
<body class="p-3 mb-2">
<a href="{{route('home')}}" class="btn btn-dark">Volver</a><br><br>
<h2 class="titulo">Crear una graella</h3>

<form style="margin-left: 30px; width: 20%;" method="GET" action="{{route('graellaStore')}}">
    <label for='id_programa' class="form-control">
    <select name="idPrograma" class="form-control">
        @foreach($programas as $p)
            <option value="{{$p -> id}}">{{$p-> namePrograma}}</option>
        @endforeach
    </select><br><br>
    <label for='dia'><b>Dia:</b></label>
    <select class="form-control" name="dia">
        <option value="Dilluns">Dilluns</option>
        <option value="Dimarts">Dimarts</option>
        <option value="Dimecres">Dimecres</option>
        <option value="Dijous">Dijous</option>
        <option value="Divendres">Divendres</option>
        <option value="Dissabte">Dissabte</option>
        <option value="Diumenge">Diumenge</option>
    </select><br><br>
    <label for='hora'><b>Hora:</b></label>
    <input name="hora" type="text" class="form-control"><br><br>
    <input class="btn btn-secondary" type="submit" value="Crear Graella">
</form>
</body>
</html>