<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Canal Creado</title>
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <style>
        .creado{
            font-family: 'Trade Winds', cursive;
            text-align: center;
        }
    </style>
</head>
<body class="p-3 mb-2">
        <a href="{{route('home')}}" class="btn btn-success">Volver</a>
        <h1 class="creado">Canal Creado Correctamente</h1>
</body>
</html>