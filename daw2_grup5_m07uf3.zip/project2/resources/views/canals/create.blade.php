<a href="{{route('home')}}"><button>Volver</button></a><br><br>
<h2 style="text-align: center;">Crear un canal</h2>

<form style="margin-left: 30px;" method="get" method="GET" action="{{route('canalsStore')}}">
    <label for='nameCanal'>Nombre Canal</label>
    <input name="nameCanal" type="text">
    <input value="Enviar" type="submit">
</form>