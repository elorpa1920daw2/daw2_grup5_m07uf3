<html>
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" 
    integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Trade+Winds&display=swap" rel="stylesheet">
    <style>
        .titulo{
            font-family: 'Trade Winds', cursive;
            text-align: center;
        }
    </style>
</head>
<body class="p-3 mb-2">
<a href="{{route('home')}}" class="btn btn-dark">Volver</a><br><br><div>
    <br>
    <h2 class="titulo">Editar un canal</h3>
    @if(count($errors) > 0)
        <div>
            <ul>
                @foreach($errors->all() as $error)
                <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    @endif
<form style="margin-left: 30px; width: 20%;" method="get" action="{{action('CanalController@update')}}">
    {{csrf_field()}}
    <label for="id"><b>Canal a renombrar:</b</label><br><br>
    <select name="id" class="form-control"> 
        @foreach($Canales as $C)
            <option value="{{$C-> id}}">{{$C-> nameCanal}}</option>
        @endforeach
    </select><br>
    <label for="nameCanal"><b>Nombre del Canal:</b></label>
    <input class="form-control" type="text" name="nameCanal" placeholder="Escribe el nombre..." /><br>
    <input class="btn btn-secondary" type="submit" value="Editar" />
</form>
</div>
</body> 
</html>